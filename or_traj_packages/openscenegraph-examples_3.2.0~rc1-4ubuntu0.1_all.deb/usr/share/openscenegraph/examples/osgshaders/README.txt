osgglsl/README.txt - mike.weiblen@3dlabs.com - 2005-03-30
Copyright 2005 3Dlabs Inc.

osgglsl began as a port of the old osgshaders example from the deprecated
osgGL2 classes to the new core GLSL classes (osg::Program, osg::Shader).

This app preserves the dynamically changing Uniforms of the original version,
but uses the new osg::Uniform classes.

